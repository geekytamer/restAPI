from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy 
from flask_marshmallow import Marshmallow 
import os

# Init app
app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))
# Database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'db.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# Init db
db = SQLAlchemy(app)
# Init ma
ma = Marshmallow(app)

# Student Model
class Student(db.Model):
  id = db.Column(db.String(6), primary_key=True)
  name = db.Column(db.String(200))
  college = db.Column(db.String(50))
  major = db.Column(db.String(50))
  gender = db.Column(db.String(10))
  GPA = db.Column(db.Float)

  def __init__(self, id, name, college, major, gender, GPA):
    self.id = id
    self.name = name
    self.college = college
    self.major = major
    self.gender = gender
    self.GPA = GPA

# Student Schema
class StudentSchema(ma.Schema):
  class Meta:
    fields = ('id', 'name', 'college', 'major', 'gender', 'GPA')

# Init schema
student_schema = StudentSchema(strict=True)
students_schema = StudentSchema(many=True, strict=True)

# Home Page
@app.route('/')
def index():
  return 'WELCOME TO SQU STUDENT REST API'


# Create a Student
@app.route('/student', methods=['POST'])
def add_student():
  id = request.json['id']
  name = request.json['name']
  college = request.json['college']
  major = request.json['major']
  gender = request.json['gender']
  GPA = request.json['GPA']

  new_student = Student(id, name, college, major, gender, GPA)

  db.session.add(new_student)
  db.session.commit()

  # Return New Student
  return student_schema.jsonify(new_student)

# Get All Students
@app.route('/student', methods=['GET'])
def get_all_student():
  all_students = Student.query.all()
  result = students_schema.dump(all_students)
  # Return All Students in db
  return jsonify(result.data)

# # Get Single Student
@app.route('/student/<id>', methods=['GET'])
def get_student(id):
  student = Student.query.get(id)
  # Return Student
  return student_schema.jsonify(student)

# Update a Student
@app.route('/student/<id>', methods=['PUT'])
def update_student(id):
  # fields = ('id', 'name', 'college', 'major', 'gender', 'GPA')

  student = Student.query.get(id)

  name = request.json['name']
  college = request.json['college']
  major = request.json['major']
  gender = request.json['gender']
  GPA = request.json['GPA']

  student.name = name
  student.college = college
  student.major = major
  student.gender = gender
  student.GPA = GPA

  db.session.commit()

  # Return Update Student
  return student_schema.jsonify(student)

# Delete student
@app.route('/student/<id>', methods=['DELETE'])
def delete_student(id):
  student = Student.query.get(id)
  db.session.delete(student)
  db.session.commit()
  
  # Return Deleted Student
  return student_schema.jsonify(student)

# Run Server
if __name__ == '__main__':
  app.run(debug=True)